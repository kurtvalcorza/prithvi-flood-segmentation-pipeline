"""Review probes for tutorials/prithvi_flood_segmentation_colab.ipynb (row 70, prefix FL).

CPU only (CUDA_VISIBLE_DEVICES=-1), no Prithvi weights loaded, no terratorch model built. Model cells are exercised
with the repository's own stub model (tests/test_adaptation.py::_StubModel), labelled as such.

Usage: python run_probes.py <worktree> <sample-cache-dir> <evidence-dir-v3> <evidence-dir-v2> <out-dir>
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time
import traceback
import types
import urllib.request
import zipfile
from pathlib import Path

WT, CACHE, EV3, EV2, OUT = (Path(a) for a in sys.argv[1:6])
NB = WT / "tutorials" / "prithvi_flood_segmentation_colab.ipynb"
RESULTS: dict = {}
T0 = time.perf_counter()


def save():
    (OUT / "results.json").write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]
md_all = "\n".join(s for s, c in zip(src, cells) if c["cell_type"] == "markdown")

# ---------------- P1: structure ----------------
compiled = {}
for i, (s, c) in enumerate(zip(src, cells)):
    if c["cell_type"] == "code":
        try:
            compile(s, f"cell{i}", "exec")
            compiled[i] = "ok"
        except SyntaxError as exc:
            compiled[i] = f"SyntaxError {exc}"
markers = {m: (m.lower() in md_all.lower()) for m in ("How to use", "Glossary", "Troubleshoot", "Infrastructure", "Check your reasoning", "audience", "Roadmap", "Predict", "threshold", "calibrat")}
RESULTS["P1_structure"] = {
    "cells": len(cells),
    "code_cells": sum(c["cell_type"] == "code" for c in cells),
    "compile": compiled,
    "guided_markers_present": markers,
    "cellView_set": [i for i, c in enumerate(cells) if c["cell_type"] == "code" and c.get("metadata", {}).get("cellView")],
    "carrier_lines": {i: len(src[i].splitlines()) for i in (5, 7, 9)},
    "image_display_calls": sum(len(re.findall(r"\b(imshow|plt\.|display\(|matplotlib)", s)) for s, c in zip(src, cells) if c["cell_type"] == "code"),
    "brace_typo_present": "{{id, image, label}}" in md_all,
    "metadata_dimer": nb["metadata"].get("dimer"),
}
save()

# ---------------- P2: repository checks ----------------
env = {**os.environ, "CUDA_VISIBLE_DEVICES": "-1", "PYTHONPATH": str(WT / "src"), "KMP_DUPLICATE_LIB_OK": "TRUE"}
p2 = {}
for name, cmd in {
    "build_check": [sys.executable, "tools/build_notebook.py", "--check"],
    "validate_release_assets": [sys.executable, "tools/validate_release_assets.py"],
    "pytest_offline": [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"],
}.items():
    r = subprocess.run(cmd, cwd=WT, env=env, capture_output=True, text=True, timeout=600)
    p2[name] = {"exit": r.returncode, "tail": (r.stdout + r.stderr).strip().splitlines()[-3:]}
RESULTS["P2_repo_checks"] = p2
save()

# ---------------- P3: prose vs the recorded run of this blob ----------------
def outputs_text(path: Path) -> dict[int, str]:
    ex = json.loads(path.read_text(encoding="utf-8"))
    out = {}
    for i, c in enumerate(ex["cells"]):
        if c["cell_type"] == "code":
            out[i] = "".join("".join(o.get("text", "")) for o in c.get("outputs", []) if o.get("output_type") == "stream")
    return out


rs3 = json.loads((EV3 / "run_summary.json").read_text(encoding="utf-8"))
ev3 = outputs_text(EV3 / "executed.ipynb")
ev2 = outputs_text(EV2 / "executed.ipynb") if (EV2 / "executed.ipynb").is_file() else {}
blob = subprocess.run(["git", "rev-parse", "HEAD:tutorials/prithvi_flood_segmentation_colab.ipynb"], cwd=WT, capture_output=True, text=True).stdout.strip()


def grab(text: str, key: str):
    m = re.search(r"\{'" + re.escape(key) + r"': (\{.*?\})\}\n", text)
    return m.group(1) if m else None


test_regions_line = re.search(r"\{'test': \{.*?'regions': (\[.*?\])\}\}", ev3.get(13, ""))
from_samples = None
sys.path.insert(0, str(WT / "src"))
from prithvi_flood_segmentation_pipeline import samples as S  # noqa: E402

test_names = [n for n, role, *_ in S.SAMPLE_RECORDS if role == "test"]
RESULTS["P3_prose_vs_record"] = {
    "reviewed_blob": blob,
    "record_blob": rs3["identity"]["committed_blob"],
    "record_blob_matches": blob == rs3["identity"]["committed_blob"],
    "record_passes": [{k: p[k] for k in ("attempt", "ok", "wall_s")} for p in rs3["runner"]["passes"]],
    "record_pass1_error_tail": rs3["runner"]["passes"][0].get("error", "")[-260:],
    "record_frozen_test": grab(ev3.get(15, ""), "frozen_test"),
    "record_comparison_water_iou": grab(ev3.get(19, ""), "water_iou"),
    "record_comparison_precision": grab(ev3.get(19, ""), "precision"),
    "record_comparison_recall": grab(ev3.get(19, ""), "recall"),
    "pre_fix_run_2026_09_19_frozen_test": grab(ev2.get(15, ""), "frozen_test") if ev2 else "evidence not present",
    "pre_fix_run_2026_09_19_water_iou": grab(ev2.get(19, ""), "water_iou") if ev2 else "evidence not present",
    "prose_claims": {
        "s5_about_0.59": "about 0.59" in src[14],
        "s5_recall_above_precision_overpredicts": "recall above precision" in src[14] and "over-predicts" in src[14],
        "s7_0.59_to_0.60": "about 0.59 to 0.60" in src[18],
        "s7_seven_regions": "seven regions" in src[18],
        "interp_near_0.6_recall_above_precision": "IoU near 0.6 and a recall above its precision" in src[22],
        "interp_seven_regions": "seven regions" in src[22],
    },
    "test_regions_in_record": json.loads(test_regions_line.group(1).replace("'", '"')) if test_regions_line else None,
    "test_regions_in_SAMPLE_RECORDS": sorted({n.split("_")[0] for n in test_names}),
    "readme_line_19_quotes_0.59": "about 0.59" in (WT / "README.md").read_text(encoding="utf-8"),
    "template_lines_quoting_0.59": [i + 1 for i, line in enumerate((WT / "tools/notebook_template.py").read_text(encoding="utf-8").splitlines()) if "0.59" in line or "seven regions" in line or "recall above" in line],
}
save()

# ---------------- P4: the Section 8 "new chips" ----------------
manifest_cell = src[11]
examples = dict(re.findall(r'"path": "examples/(\w+)_S2Hand\.tif",\s*"bytes": \d+,\s*"sha256": "([0-9a-f]+)"', manifest_cell))
sample_img_sha = {n: sha for n, _r, _b, sha, *_ in S.SAMPLE_RECORDS}
sample_role = {n: r for n, r, *_ in S.SAMPLE_RECORDS}
p4 = {"examples": {}}
for name, sha in examples.items():
    p4["examples"][name] = {"in_SAMPLE_RECORDS": name in sample_img_sha, "role": sample_role.get(name), "image_sha256_identical": sample_img_sha.get(name) == sha}
splits = {}
for split in ("train", "valid", "test", "bolivia"):
    url = f"https://storage.googleapis.com/sen1floods11/v1.1/splits/flood_handlabeled/flood_{split}_data.csv"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "review-probe"}), timeout=60) as r:
            text = r.read().decode("utf-8")
        splits[split] = {row[0].replace("_S1Hand.tif", "") for row in csv.reader(io.StringIO(text)) if row}
    except Exception as exc:  # noqa: BLE001
        splits[split] = f"fetch failed: {exc}"
for name in examples:
    p4["examples"][name]["upstream_split"] = [s for s, v in splits.items() if isinstance(v, set) and name in v]
p4["split_sizes"] = {s: (len(v) if isinstance(v, set) else v) for s, v in splits.items()}
RESULTS["P4_new_chips"] = p4
save()

# ---------------- P5: BYOD loader on synthetic zips ----------------
import numpy as np  # noqa: E402
import tifffile  # noqa: E402

sys.path.insert(0, str(WT / "tests"))
from conftest import synthetic_chip  # noqa: E402

work = OUT / "work"
work.mkdir(exist_ok=True)


def make_zip(path: Path, n: int, *, missing=False, non_tiff=False) -> Path:
    with zipfile.ZipFile(path, "w") as z:
        rows = ["id,image,label"]
        for i in range(n):
            img, lab = synthetic_chip(seed=i)
            b1, b2 = io.BytesIO(), io.BytesIO()
            tifffile.imwrite(b1, img, photometric="minisblack", planarconfig="separate")
            tifffile.imwrite(b2, lab.astype(np.int16), photometric="minisblack")
            if not (missing and i == 0):
                z.writestr(f"c{i}.tif", b"not a tiff" if (non_tiff and i == 0) else b1.getvalue())
            z.writestr(f"m{i}.tif", b2.getvalue())
            rows.append(f"chip{i},c{i}.tif,m{i}.tif")
        z.writestr("pairs.csv", "\n".join(rows) + "\n")
    return path


p5 = {}
for label, kw in {**{f"valid_n{n}": {"n": n} for n in (4, 5, 6, 7, 8)}, "missing_member": {"n": 8, "missing": True}, "non_tiff": {"n": 8, "non_tiff": True}}.items():
    z = make_zip(work / f"{label}.zip", **kw)
    try:
        recs = S.load_byod_dataset(z)
        sp = S.split_dataset(recs, seed=0)
        p5[label] = {"ok": True, "split": {k: len(v) for k, v in sp.items()}, "record_keys": sorted(recs[0].keys())}
    except Exception as exc:  # noqa: BLE001
        p5[label] = {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:140]}"}
RESULTS["P5_byod_loader"] = p5
save()

# ---------------- P6: notebook cells 13/15/17/19 with the repository stub model ----------------
import torch  # noqa: E402
from test_adaptation import _StubModel  # noqa: E402

ns: dict = {"__name__": "__main__"}
run_dir = work / "nbrun"
run_dir.mkdir(exist_ok=True)
os.chdir(run_dir)
for i in (5, 7, 9):
    exec(compile(src[i], f"cell{i}", "exec"), ns)
ns["torch"] = torch
ns["pipe"] = ns["PrithviFloodPipeline"](model=_StubModel(), device="cpu", weights_dir=Path("unused"), source="stub")
p6: dict = {"model": "repository stub (_StubModel), CPU; not Prithvi"}


def run_cell(i: int, *, replace: dict | None = None):
    code = src[i]
    for a, b in (replace or {}).items():
        assert a in code, a
        code = code.replace(a, b)
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        exec(compile(code, f"cell{i}", "exec"), ns)
        err = None
    except Exception as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    finally:
        sys.stdout = old
    return {"error": err, "stdout_tail": buf.getvalue().strip().splitlines()[-4:]}


cache_abs = str(CACHE).replace("\\", "/")
p6["default_c13"] = run_cell(13, replace={"cache_dir='weights/sen1floods11'": f"cache_dir={cache_abs!r}"})
p6["default_c15"] = run_cell(15)
p6["default_c17"] = run_cell(17)
p6["default_c19"] = run_cell(19)
p6["default_frozen_test_water_iou"] = ns["frozen_test"]["model"]["iou"]["water"]
p6["default_adapted_test_water_iou"] = ns["adapted_test"]["model"]["iou"]["water"]

# BYOD as documented: USE_BYOD = True, re-run from Section 4 (fake Colab upload of an 8-chip synthetic zip)
byod_zip = make_zip(work / "byod8.zip", 8)
colab = types.ModuleType("google.colab")
colab.files = types.SimpleNamespace(upload=lambda: {"byod8.zip": byod_zip.read_bytes()})
google = types.ModuleType("google")
google.colab = colab
sys.modules["google"], sys.modules["google.colab"] = google, colab
p6["byod_c13"] = run_cell(13, replace={"USE_BYOD = False": "USE_BYOD = True"})
p6["byod_c15"] = run_cell(15)
p6["byod_c15_frozen_test_water_iou_reported"] = ns["frozen_test"]["model"]["iou"]["water"]
fresh = ns["PrithviFloodPipeline"](model=_StubModel(), device="cpu", weights_dir=Path("unused"), source="stub")
p6["byod_true_frozen_test_water_iou"] = fresh.evaluate(ns["test_records"])["model"]["iou"]["water"]
# continue past the crash the way a learner would have to (skip the per-chip print loop) and adapt again
p6["byod_c17"] = run_cell(17)
hist = ns["adapt_result"]["history"]
p6["byod_epoch0"] = {"note": hist[0].get("note"), "val_loss": round(hist[0]["val_loss"], 4)}
true0 = fresh.adapt(ns["train_records"], ns["val_records"], epochs=1, lr=1e-5)["history"][0]
p6["byod_true_frozen_epoch0_val_loss"] = round(true0["val_loss"], 4)
# TRAINABLE experiment then back to the default: last encoder block keeps its change but is not exported
exp = ns["PrithviFloodPipeline"](model=_StubModel(), device="cpu", weights_dir=Path("unused"), source="stub")
recs = ns["train_records"]
exp.adapt(recs, ns["val_records"], epochs=2, lr=1e-3, trainable="decoder+last_block")
w_after_exp = float(exp.model.encoder.blocks[23].w)
exp.adapt(recs, ns["val_records"], epochs=1, lr=1e-3, trainable="decoder")
p6["trainable_switch"] = {"last_block_w_base": 1.0, "after_decoder+last_block": round(w_after_exp, 6), "after_rerun_decoder": round(float(exp.model.encoder.blocks[23].w), 6), "exported_names": exp.adapter["trainable_names"]}

# ---------------- P7: is the exported pairs CSV a working BYOD template? ----------------
default_splits = S.fetch_sample_dataset(cache_dir=CACHE)
csv_path = S.write_dataset_csv(default_splits["test"], work / "pairs_export.csv")
rows = list(csv.DictReader(open(csv_path, encoding="utf-8")))
z7 = work / "from_export.zip"
with zipfile.ZipFile(z7, "w") as z:
    z.writestr("pairs.csv", csv_path.read_text(encoding="utf-8"))
    for row in rows:
        for key in ("image", "label"):
            z.write(CACHE / row[key], row[key])
try:
    loaded = S.load_byod_dataset(z7)
    p7 = {"ok": True, "records": len(loaded), "split": {k: len(v) for k, v in S.split_dataset(loaded, seed=0).items()}}
except Exception as exc:  # noqa: BLE001
    p7 = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
p7["csv_names_example"] = rows[0]["image"]
p7["names_match_written_outputs"] = rows[0]["image"] == "prithvi_flood_segmentation_sample_chip.tif"
RESULTS["P7_pairs_csv_template"] = p7
RESULTS["P6_notebook_cells_stub"] = p6
RESULTS["elapsed_s"] = round(time.perf_counter() - T0, 1)
save()
print(json.dumps(RESULTS, indent=1, default=str)[:12000])
